# memory
Memory game - just a simple children's game

Version 1.0 - done
  * display board and pairs won by each player
  * display instructions

Version 1.1 - done
  * Players can select names
  * Screen toggles between name input and display of game results

Version 1.2 - done
  * JS procedures organized to transition to OOP

Version 1.3
  * Use OOP for JS code

Version 1.4
  * use Bootstrap to make display responsive

Version 2.0
  * Allow user to log in

Version 2.1
  * Allow user to store game results
